<?php
class equipment_Controller
{
    public function index()
    {
        $equipmentlist = equipment::getAll();
        require_once('views/equipment.php') ;
    }
    public function delete()
   {
    $equ_id =$_GET['equ_id'];
    equipment::delete($equ_id);
    equipment_Controller::index();
   
   }
}
?>