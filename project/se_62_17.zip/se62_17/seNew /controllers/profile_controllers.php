<?php
class ProfileController{
    public function home()
    {
        require_once('views/profile.php') ;
    }
}