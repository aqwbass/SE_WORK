<?php
class equipment{
        public $equ_id;
        public $equ_img;
        public $equ_name ;
        public $equ_serialnumber ;
        public $equ_price ;
        public $equ_details;
        public $equ_buy ;
        public $type_name ;
        
        //add methond here
        public function equipment($equ_id,$equ_img,$equ_name,$equ_serialnumber,$equ_price ,$equ_details,$equ_buy,$type_name)
        {
                $this->equ_id = $equ_id;
                $this->equ_img = $equ_img;
                $this->equ_name= $equ_name ;
                $this->equ_serialnumber= $equ_img ;
                $this->equ_price= $equ_price ;
                $this->equ_details= $equ_details;
                $this->equ_buy= $equ_buy ;
                $this->type_name= $type_name ;
                
        }
        public static function getAll()
        {
                $equipmentlist = [] ;
                require("connection_connect.php");
                $sql = "SELECT * FROM equipment,equipment_type WHERE equipment.type_id = equipment_type.type_id  
                ORDER BY `equipment`.`equ_id` ASC";
                $result = $conn->query($sql);
                while($my_row=$result->fetch_assoc())
                {
                     $equ_id =$my_row['equ_id'];
                     $equ_img =$my_row['equ_img'];
                     $equ_name=$my_row['equ_name'];
                     $equ_serialnumber =$my_row['equ_serialnumber'];
                     $equ_price =$my_row['equ_price'];
                     $equ_details=$my_row['equ_details'];
                     $equ_buy =$my_row['equ_buy'];
                     $type_name =$my_row['type_name'];
                     $equipmentlist[]=new equipment($equ_id,$equ_img,$equ_name,$equ_serialnumber,$equ_price ,$equ_details,$equ_buy,$type_name);
                }
                //require("connection_close.php");
                return $equipmentlist;
                
        }
        public static function delete($equ_id)
    {
        require("connection_connect.php");
        $sql ="DELETE from equipment Where equ_id='$equ_id'";
        $result=$conn->query($sql);
        //require("connection_close.php");
        return "delete success $result row";
    }
    }
    ?>