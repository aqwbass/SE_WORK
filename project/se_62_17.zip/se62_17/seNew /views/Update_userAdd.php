<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
<i class="fas fa-plus"></i>
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">เพิ่มผู้ใช้</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form class="needs-validation" novalidate method="get" action="">
  <div class="form-row">
    <div class="col-md-4 mb-3">
      <label for="validationCustom01">หมายเลขประจำตัว</label>
      <input type="text" class="form-control" id="validationCustom01" placeholder="กรอกหมายเลข" name = "us_id" required>
      <div class="invalid-feedback">
      โปรดกรอกข้อมูล
      </div>
    </div>
    
  </div>
  <div class="form-row">
 <div class="col-md-6 mb-3">
      <label for="validationCustomUsername">ชื่อจริง</label>
      <div class="input-group">
        <div class="input-group-prepend">
        </div>
        <input type="text" class="form-control" id="validationCustomUsername" placeholder="กรอกชื่อจริง" aria-describedby="inputGroupPrepend" name = "us_firstName" required>
        <div class="invalid-feedback">
          โปรดกรอกข้อมูล
        </div>
      </div>
    </div>

    <div class="col-md-6 mb-3">
      <label for="validationCustom03">นามสกุล</label>
      <input type="text" class="form-control" id="validationCustom03" placeholder="กรอกนามสกุล" name ="us_lastName" required>
      <div class="invalid-feedback">
      โปรดกรอกข้อมูล
      </div>
    </div>
    
    
  </div>
  <div class="form-row">
    <div class="col-md-6 mb-3">
      <label for="validationCustom03">หมายเลขโทรศัพท์</label>
      <input type="text" class="form-control" id="validationCustom03" placeholder="" name ="us_phone" required>
      <div class="invalid-feedback">
      โปรดกรอกข้อมูล
      </div>
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationCustom03">ตำแหน่ง</label>
      <input type="text" class="form-control" id="validationCustom03" placeholder="" name ="us_role" required>
      <div class="invalid-feedback">
      โปรดกรอกข้อมูล
      </div>
    </div>
    <div class="form-row">
    <div class="col-md-6 mb-3">
      <label for="validationCustom03">อีเมล</label>
      <input type="text" class="form-control" id="validationCustom03" placeholder="" name ="us_email" required>
      <div class="invalid-feedback">
      โปรดกรอกข้อมูล
      </div>
    </div>
    <div class="col-md-6 mb-3">
      <label for="validationCustom03">เลือกไฟล์รูป</label>
      <input type="text" class="form-control" id="validationCustom03" placeholder="" name ="us_img" required>
      <div class="invalid-feedback">
      โปรดกรอกข้อมูล
      </div>
    </div>
  </div>
 
  <input type ="hidden"name="controller" value="Update_user"/>
  <button class="btn btn-primary" type="submit" name="action" value="add" data-toggle="modal" data-target="#exampleModalLong" >Submit form</button>
  
</form>
<script>
// Example starter JavaScript for disabling form submissions if there are invalid fields
(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();
</script>
      </div>
      
    </div>
  </div>
</div>