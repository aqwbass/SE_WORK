<table id="table_id" class="display">
    <thead>
        <tr>
            <th>ลำดับ</th>
            <th>รูปภาพ</th>
            <th>หมวดหมู่</th>
            <th>ชื่ออุปกรณ์</th>
            <th>เลขครุภัณฑ์</th>
            <th>ราคา</th>
            <th>รายละเอียด</th>
            <th>วันที่ซื้อ</th>
            <th><i class="fas fa-trash-alt"></i></th>
            <th><i class="fas fa-pencil-alt"></i></th>
        </tr>
        </thead>
        <?php foreach($equipmentlist as $equ)
        {
            echo'
        <tr>
            <td>'.$equ->equ_id.'</td>
            <td><i class="fas fa-image"></i></td>
            <td>'.$equ->type_name.'</td>
            <td>'.$equ->equ_name.'</td>
            <td>'.$equ->equ_serialnumber.'</td>
            <td>'.$equ->equ_price.'</td>
            <td>'.$equ->equ_details.'</td>
            <td>'.$equ->equ_buy.'</td>
            <td><a type="button" class="btn btn-outline-danger" href="?controller=equipment&action=delete&equ_id='.$equ->equ_id.'"  onclick="myFunction(event)"><i class="fas fa-trash-alt"></i></a></td>
            <td><button type="button" class="btn btn-outline-warning"><i class="fas fa-pencil-alt"></i></button></td>
        </tr>
        ';
        }
    echo "</table>"; 
?>
 <script>
function myFunction(e) {
  if(!confirm(`Are you sure  ?`) ) e.preventDefault();

}</script>