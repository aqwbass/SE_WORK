<!doctype html>
<html lang="en">
  <head>
<div class="container">
    <div class="row">
        <div class="col-sm">
    <title>จัดการข้อมูลผู้ใช้</title>
  </head> 
  <body>
    <div class="row">
      <div class="card-columns">
    <?php 
    //require_once("../routes.php");
    foreach($Update_user_list as $user)
    {
      echo'<div class="card">
          <img class="card-img-top" src="./man-300x300.png" alt="">
          <div class="card-body">
            <h10 class="card-title">'.$user->us_id.'<br>'.$user->us_phone.'</h10>
            <p class="card-text">'.$user->us_role.'</p>
          </div>
          <div class="card-footer text-muted">
          <a type="button" class="btn btn-outline-danger" href="?controller=Update_user&action=delete&us_id='.$user->us_id.'"  onclick="myFunction(event)"><i class="fas fa-trash-alt"></i></a>
          <button type="button" class="btn btn-outline-warning"><i class="fas fa-pencil-alt"></i></button>
          </div>
        </div>';
    }
    
    ?>
      </div>
   </div>
  </div>
  </div>
  </div>

    <!-- Optional JavaScript -->
    <script>
function myFunction(e) {
  if(!confirm(`Are you sure  ?`) ) e.preventDefault();

}</script>
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  </body>
</html>

  