-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 26, 2020 at 03:05 AM
-- Server version: 5.7.29-0ubuntu0.16.04.1
-- PHP Version: 7.2.28-3+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `se62_17`
--

-- --------------------------------------------------------

--
-- Table structure for table `basket`
--

CREATE TABLE `basket` (
  `basket_id` int(11) NOT NULL,
  `equ_id` int(11) NOT NULL,
  `us_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='ตารางตะกร้าใส่อุปกรณ์';

--
-- Dumping data for table `basket`
--

INSERT INTO `basket` (`basket_id`, `equ_id`, `us_id`) VALUES
(1, 1, 'adt453'),
(2, 2, 'B6020554321'),
(3, 3, 'teac9876'),
(4, 4, 'B6020551822'),
(5, 5, 'B6020554321');

-- --------------------------------------------------------

--
-- Table structure for table `borrow`
--

CREATE TABLE `borrow` (
  `br_id` int(11) NOT NULL,
  `br_date` date NOT NULL,
  `br_status` varchar(50) NOT NULL,
  `br_unit` int(20) NOT NULL,
  `bo_id` varchar(50) NOT NULL,
  `approved_by` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='ตารางการยืมอุปกรณ์';

--
-- Dumping data for table `borrow`
--

INSERT INTO `borrow` (`br_id`, `br_date`, `br_status`, `br_unit`, `bo_id`, `approved_by`) VALUES
(1, '2020-03-05', 'noreturn', 2, '1', 'admin'),
(2, '2020-03-06', 'return', 5, '2', 'teach boonyarat'),
(3, '2020-02-29', 'noreturn', 1, '3', 'admin'),
(4, '2020-03-02', 'noreturn', 3, '4', 'teacher sivadon'),
(5, '2020-03-01', 'return', 2, '5', 'teacher Boonyarat\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `borrow_order`
--

CREATE TABLE `borrow_order` (
  `bo_id` int(11) NOT NULL,
  `bo_date` date NOT NULL,
  `status_approved` varchar(20) NOT NULL,
  `basket_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `borrow_order`
--

INSERT INTO `borrow_order` (`bo_id`, `bo_date`, `status_approved`, `basket_id`) VALUES
(1, '2020-03-01', 'approved', '0001'),
(2, '2020-03-02', 'approved', '0002'),
(3, '2020-02-28', 'approved', '0003'),
(4, '2020-02-29', 'approved', '0004'),
(5, '2020-02-28', 'approved', '0005');

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

CREATE TABLE `equipment` (
  `equ_id` int(11) NOT NULL,
  `equ_img` varchar(50) NOT NULL,
  `equ_name` varchar(50) NOT NULL,
  `equ_serialnumber` varchar(50) NOT NULL,
  `equ_price` int(10) NOT NULL,
  `equ_details` varchar(1000) NOT NULL,
  `equ_buy` date NOT NULL,
  `type_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='ตารางอุปกรณ์';

--
-- Dumping data for table `equipment`
--

INSERT INTO `equipment` (`equ_id`, `equ_img`, `equ_name`, `equ_serialnumber`, `equ_price`, `equ_details`, `equ_buy`, `type_id`) VALUES
(1, 'imgcapacitor', 'capacitor', 'cn8888888', 15, 'manner DNA', '2020-02-17', 1),
(2, 'imgcpu', 'cpu', 'cpu897653', 20000, 'manner acer ,waigth 3 kg', '2020-03-02', 2),
(3, 'imgcpu', 'cpu', 'ko2', 20000, 'manner asus', '2019-07-16', 2),
(4, 'imgdiode', 'diode', 'do134567', 20, ' Light-emitting diode', '2019-11-03', 1),
(5, 'imgdiode', 'diode', 'k01', 20, 'manner Haco', '2020-02-18', 1),
(6, 'imgdisplaycard', 'displaycard', 'dp123', 510, 'manner gdh', '2020-02-29', 2),
(7, 'imgharddisk', 'harddisk', 'hd90023', 5000, 'the 350 disk storage, shipped in 1957 as a component of the IBM 305 RAMAC system', '2019-11-04', 2),
(8, 'imgkeyboard', 'keyboard', 'kb0000123', 500, 'manner nano 1234', '2020-03-01', 2),
(9, 'imgloudspeaker', 'loudspeaker', 'lsk666555', 5000, 'manner haco 13m', '2020-03-04', 2),
(10, 'imgmainboard', 'mainboard', 'mb1123409', 7000, 'manner cmfr', '2020-02-10', 2),
(11, 'imgmicrophone', 'microphone', 'mcp999876', 500, 'manner Haco 300 cm', '2020-03-02', 3),
(12, 'imgmonitor', 'moniter', 'c0001', 2000, 'display 1280 x 1230', '2019-12-31', 2),
(13, 'imgmonitor', 'moniter', 'kt435', 5000, 'display 1340*1500', '2020-02-03', 2),
(14, 'imgmonitor', 'monitor', 'ytr435', 4000, 'display 1340*1500 manner acer', '2019-12-31', 2),
(15, 'imgmouse', 'mouse', 'm0012', 500, 'manner nano', '2020-03-09', 2),
(16, 'imgmouse', 'mouse', 'b51', 360, 'manner fax', '2020-02-02', 2),
(17, 'imgpowersupply', 'powersupply', 'pw004', 10000, 'manner DNA', '2020-02-02', 2),
(18, 'imgram', 'ram', 'ram60001', 2000, 'manner toto 4GB', '2020-03-02', 2);

-- --------------------------------------------------------

--
-- Table structure for table `equipment_type`
--

CREATE TABLE `equipment_type` (
  `type_id` int(20) NOT NULL,
  `type_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='ตารางหมวดหมู่อุปกรณ์';

--
-- Dumping data for table `equipment_type`
--

INSERT INTO `equipment_type` (`type_id`, `type_name`) VALUES
(1, ' electronics'),
(2, 'computer'),
(3, 'electrical');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `us_id` varchar(20) NOT NULL,
  `us_firstName` varchar(50) NOT NULL,
  `us_lastName` varchar(20) NOT NULL,
  `us_phone` varchar(11) NOT NULL,
  `us_role` varchar(50) NOT NULL,
  `us_email` varchar(50) NOT NULL,
  `us_img` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='ตารางผู้ใช้';

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`us_id`, `us_firstName`, `us_lastName`, `us_phone`, `us_role`, `us_email`, `us_img`) VALUES
('admin1234', 'sasithorn', '', '0816997651', 'admin', 'sasithorn@hotmail.com', 'imgsasithorn'),
('adt453', 'punnawit', '', '064-2341236', 'teacher', 'punnawit@hotmail.com', 'imgpunnawit'),
('B6020551822', 'thidarat phukruthai', '', '062-3064012', 'student', 'thidarat@hotmail.com', 'imgthidarat'),
('b6020551911', '', '', '', 'Student', '', ''),
('B6020554321', 'soraya meedee', '', '087-6543210', 'student', 'soraya@hotmail.com', 'imgsoraya'),
('fengncn', '', '', '', 'Teacher', '', ''),
('fengsstc', '', '', '', 'Admin', '', ''),
('testtts', 'bass', 'dw', '0897299224', 'admin', 'asdfsdf@gmaiol.com', 'asdfasdfasfa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `basket`
--
ALTER TABLE `basket`
  ADD PRIMARY KEY (`basket_id`),
  ADD KEY `us_id` (`us_id`);

--
-- Indexes for table `borrow`
--
ALTER TABLE `borrow`
  ADD PRIMARY KEY (`br_id`),
  ADD KEY `bo_id` (`bo_id`);

--
-- Indexes for table `borrow_order`
--
ALTER TABLE `borrow_order`
  ADD PRIMARY KEY (`bo_id`),
  ADD KEY `basket_id` (`basket_id`);

--
-- Indexes for table `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`equ_id`),
  ADD UNIQUE KEY `equ_serialnumber_3` (`equ_serialnumber`),
  ADD KEY `type_id` (`type_id`),
  ADD KEY `equ_serialnumber` (`equ_serialnumber`),
  ADD KEY `equ_serialnumber_2` (`equ_serialnumber`);

--
-- Indexes for table `equipment_type`
--
ALTER TABLE `equipment_type`
  ADD PRIMARY KEY (`type_id`),
  ADD KEY `type_name` (`type_name`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`us_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `basket`
--
ALTER TABLE `basket`
  MODIFY `basket_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `borrow`
--
ALTER TABLE `borrow`
  MODIFY `br_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `borrow_order`
--
ALTER TABLE `borrow_order`
  MODIFY `bo_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `equipment`
--
ALTER TABLE `equipment`
  MODIFY `equ_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `equipment_type`
--
ALTER TABLE `equipment_type`
  MODIFY `type_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
